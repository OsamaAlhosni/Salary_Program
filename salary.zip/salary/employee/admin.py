from django.contrib import admin

from .models import Salary,Loan,Mangement,Employee

admin.site.register(Salary)
admin.site.register(Loan)
admin.site.register(Mangement)
admin.site.register(Employee)

