from django.apps import AppConfig


class EmportSalaryConfig(AppConfig):
    name = 'emport_salary'
